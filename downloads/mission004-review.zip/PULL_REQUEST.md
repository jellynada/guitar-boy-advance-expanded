## Problem and behavior

Clone Hero packages often contain MIDI instead of .chart, plus INI metadata and
multiple audio stems. Mission003 could only prepare individual .chart files.
This adds a bounded MIDI reader and a unified ZIP/folder/file inspector producing
exact normalized song JSON and readable compatibility reports. It discovers audio
without decoding it, preserves unsupported markers explicitly and requires choices
for competing charts, ambiguous audio and conflicting offsets.

Both formats share exact timing/spans and compatibility analysis. Four native
difficulties remain separate, lanes are not collapsed, and opposing/diagonal D-pad
onsets and held-sustain combinations are reported. No live game assets/code,
controls, judgment windows or renderer changed. Existing chart workflow remains.
No target Cream package was available or analyzed, and no third-party chart/audio
is added. New fixtures are original synthetic events.

## Validation

- 32 existing chart-importer tests +34 MIDI/package tests passed, no skips;
  existing sanitizer/judgment and complete699-note tests passed.
- Independent timing assertions, equivalent chart/MIDI timestamps, every-prefix
  truncation, running status, pairing, markers, offsets, package ambiguity,
  audio discovery, safe ZIP limits and deterministic outputs.
- Clean native and pinned Docker builds:289840-byte ROM, SHA256
  `853ccc89e4e6da2b95ba4fa32ab9ca4fc53937fef257d55e2a9f41522ca823e8`, identical toM2/M3.
- Actual mGBA0.10.1:36000frames each perfect/miss/mixed; allpassed, no core crash.
  Perfect699; Miss699; mixed85Perfect/123Good/491Miss. No manual play/listening claim.

## Boundaries and review

Imported JSON is not playable yet. SysEx effects, automatic HOPO/sustain rules,
audio conversion/calibration, lane renderers and runtime integration remain future
work. Package command does not produce an incompatible MIDI header. Python3.10+,
standard library only. See docs/SONG_PACKAGE_IMPORT.md and MISSION_004_RESULTS.md.

Review against mission-003-chart-importer to show Mission004 only; main has no
previous mission merges. No automatic merge. The separate mission-004-download
branch contains the review bundle and must not be merged into source/main.
