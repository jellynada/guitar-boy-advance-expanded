MISSION014 SYNTHETIC REVIEW BUILD
Extract All. Install mGBA from https://mgba.io/downloads.html.
File > Load ROM > Guitar-Boy-Advance-M014-Synthetic.gba
This public test song is synthetic. No Cream recording/chart is included.
START pauses/resumes imported gameplay. SELECT exits while paused. Frets: LEFT/B/A.
Cream is retained locally until an authorized private transfer is available.
No compilation is needed to play this synthetic ROM. The developer launcher is preserved.
Review candidate, not a stable release. Read docs/KNOWN_ISSUES.md.
