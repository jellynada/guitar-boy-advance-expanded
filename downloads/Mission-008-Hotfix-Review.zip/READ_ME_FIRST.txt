MISSION 008 HOTFIX - SYNTHETIC SOURCE REVIEW

This ZIP contains an original synthetic 25-note exercise, not Cream.
Extract All, open Guitar-Boy-Advance-Mission-008-Hotfix-Synthetic.gba in mGBA,
confirm M008 HOTFIX 1, and choose Imported Easy Test. Left / A / B controls.
Full source, native screenshots, and validation limits are included.
For the actual Cream song use the separate Sunshine-of-Your-Love hotfix ZIP.

Source revision: 71f0152c29d7008acd310808861643d5018e65a7
