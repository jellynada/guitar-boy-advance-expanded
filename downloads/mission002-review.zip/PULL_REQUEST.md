## Mission 002: reliable note judgment and requested Left/Right/A/B controls

This builds on Mission 001's working fixes at 47d340e. The review base is mission-001-reproducible-build because those fixes have not been merged into main. No automatic merge is requested.

Each chart record now transitions once from Pending to Perfect, Good or Missed. Fresh presses are judged in their own lanes; held buttons cannot retrigger, partial chords are counted per note, and wrong extra presses cannot consume valid notes. Per-note gameplay events and consistent hit/miss counters are separated from rendering and audio.

The owner explicitly changed the mission brief's old controls to **D-pad Left, D-pad Right, A, B**, from left to right. One mapping drives input and the original fret animations. Perfect is 25 ms, Good is up to 50 ms early/85 ms late, converted using actual GBA frame timing. The latest judgment, H/M counters and a separate WRONG flash use existing font art. Hit sprites retain their chart identity/state through recycling.

The chart, module music, camera/projection formulas, art, devkitARM image and build script remain unchanged. Compiler-specific desktop-converter cache names fix a native/container C++ runtime incompatibility. No new song, menus, points/multipliers, sustains, star power or reactive audio is added.

## Validation

- ASan/UBSan with fatal errors and leak checking: timing boundaries, input/chords/holds, repeats, reset, final/empty charts and control mapping pass.
- Unchanged 699-note chart: all-miss and all-perfect host runs, one event per note, consistent statistics.
- Actual mGBA, 36000 frames each: scheduled presses 699 Perfect; no input 699 Miss; mixed input 85 Perfect / 123 Good / 491 Miss, with separate WrongInput events.
- Active hit-sprite tile verified in actual OAM for 6081 frames in the successful-input run. Framebuffer and audio samples verified; no emulator core crashes.
- Clean native/container builds, generated-header recovery and switching native to Docker all produce SHA-256 853ccc89e4e6da2b95ba4fa32ab9ca4fc53937fef257d55e2a9f41522ca823e8.

No manual Mission 002 playthrough, listening, latency calibration or physical GBA test was performed. Music still loops without restarting the chart, the legacy timing/audio-clock assumptions remain, and real D-pads cannot normally hold Left+Right together (the supplied chart has no chords). Asset rights are not newly established.

Documentation: README, docs/PROJECT_STATUS.md, docs/NOTE_JUDGMENT.md and docs/MISSION_002_RESULTS.md. Tested binaries are published separately on mission-002-download at the owner's request; do not merge that download branch.
