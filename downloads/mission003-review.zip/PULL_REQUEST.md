## Mission 003: prepare community charts with exact tempo timing

Based on tested Mission 002 at 5338621, which includes Mission 001. Review base is mission-002-note-judgment because those fixes remain unmerged into main. Do not automatically merge.

Adds an independent Python-standard-library .chart parser/validator and one-command import workflow. It reads metadata, all tempo changes, signatures, offsets and independent Single difficulties, integrates exact rational audio-origin timestamps, preserves chord ordering/sustains/modifiers/open notes, and generates readable/JSON reports, normalized song JSON and C++17 prepared tables. Invalid/duplicate/unsorted/overflowing events fail explicitly; unsupported instrument/event data is retained with warnings. Planned 3/4/5-lane layouts and D-pad chord issues are reported without remapping lanes or relabeling Expert.

The live legacy converter, game source, Makefile, 699-note demo, graphics, Left/Right/A/B controls and audio are unchanged. New absolute-time data is intentionally **prepared, not playable** until a separately verified runtime/audio adapter exists. No new renderer, song selection, sustain gameplay, score system or audio feature is added.

## Validation

- Existing Mission 002 ASan/UBSan/leak and 699-note checks pass.
- 32 importer tests pass: independently calculated constant/changing-tempo times, boundaries, resolution, chords, sustain crossing changes, signed offsets, markers, malformed data/overflow, source-order preservation, CLI/determinism and stale-output handling.
- Prepared headers compile with host GCC and actual devkitARM ARM7TDMI/Thumb, including signed 64-bit endpoints.
- Original demo imports as 699 ExpertSingle notes. Clean pinned-container ROM build remains byte-identical to Mission 002: SHA-256 853ccc89e4e6da2b95ba4fa32ab9ca4fc53937fef257d55e2a9f41522ca823e8.
- Actual mGBA 0.10.1 run: 36000 frames, 699 Perfect, no misses/wrong inputs/core crash; framebuffer, audio samples and active hit sprites verified. No manual play/listening, hardware or perfect synchronization claim.

No authorized Sunshine of Your Love chart was supplied; none was fabricated/downloaded. No Cream recording, new audio or official Guitar Hero assets were obtained. Fixtures are original synthetic examples. Incoming/generated files are ignored by Git to avoid accidental redistribution. A GHIII cover chart is not assumed to fit Cream's original recording.

Docs: CHART_IMPORT_GUIDE.md, SONG_DATA_ARCHITECTURE.md, PROJECT_STATUS.md and MISSION_003_RESULTS.md. Matching authorized recording, timing adapter/pre-roll/calibration and future lane rendering remain explicit Mission 004 decisions. The separate download branch is not intended for merging.
