// Generated prepared data. NOT the live demo Note ABI; no runtime binding.
#pragma once
#include <array>
#include <cstdint>
namespace imported_song_e8f475ca5971 {
struct Note { int64_t start_us; int64_t duration_us; uint8_t lane; uint8_t kind; };
// kind: 0 = fretted (lane 0..4), 1 = open (lane 255).
struct Modifier { int64_t start_us; int64_t duration_us; uint8_t kind; };
// modifier kind: 5 = strum/HOPO flip, 6 = tap; not applied to gameplay.
struct Tempo { uint64_t tick; uint32_t milli_bpm; int64_t time_us; };
struct Meter { uint64_t tick; uint32_t numerator; uint32_t denominator; };
inline constexpr std::array<Tempo, 3> tempos{{
    {0ULL, 120000U, 250000LL},
    {384ULL, 60000U, 1250000LL},
    {576ULL, 240000U, 2250000LL},
}};
inline constexpr std::array<Meter, 2> meters{{
    {0ULL, 4U, 4U},
    {384ULL, 3U, 4U},
}};
inline constexpr std::array<Note, 3> easy_single_notes{{
    {250000LL, 0LL, 0, 0},
    {750000LL, 0LL, 1, 0},
    {1250000LL, 0LL, 2, 0},
}};
inline constexpr std::array<Modifier, 0> easy_single_modifiers{{
}};
inline constexpr std::array<Note, 5> medium_single_notes{{
    {750000LL, 1750000LL, 0, 0},
    {1250000LL, 0LL, 1, 0},
    {1250000LL, 0LL, 3, 0},
    {2250000LL, 0LL, 2, 0},
    {2500000LL, 0LL, 3, 0},
}};
inline constexpr std::array<Modifier, 0> medium_single_modifiers{{
}};
inline constexpr std::array<Note, 3> hard_single_notes{{
    {1250000LL, 0LL, 0, 0},
    {1250000LL, 0LL, 2, 0},
    {2250000LL, 0LL, 4, 0},
}};
inline constexpr std::array<Modifier, 0> hard_single_modifiers{{
}};
inline constexpr std::array<Note, 2> expert_single_notes{{
    {750000LL, 0LL, 4, 0},
    {1250000LL, 1000000LL, 255, 1},
}};
inline constexpr std::array<Modifier, 2> expert_single_modifiers{{
    {750000LL, 0LL, 5},
    {1250000LL, 0LL, 6},
}};
} // namespace
