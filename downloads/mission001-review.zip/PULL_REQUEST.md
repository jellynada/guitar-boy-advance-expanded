## Problem and result

Clean builds required a Windows-only chart converter, and the end-of-song note and sprite lookups could read past their arrays. Mission 001 makes the supplied song build with the native host converter and bounds those reads while retaining the existing visuals, assets, controls and timing formulas.

## Changes

- Automatically compile the C++17 host converter and generate note.h; group related outputs for parallel Make builds.
- Assert the 16-byte note record layout and align chart data to 8 bytes; reject missing/zero resolution.
- Bound note/sprite cursors, initialize note positions, use signed timestamp conversion and a 64-bit highway accumulator.
- Initialize audio before its interrupt callback and protect song-clock reads during hit checking.
- Add a pinned Docker build, sanitizer/converter regression checks, optional headless mGBA smoke test, beginner README and project-status documentation.

## Validation

Clean native and pinned-container builds produced the same ROM checksum. Rebuilding with note.h deleted succeeded. Host ASan/UBSan tests and all 699 linked record comparisons passed. See docs/BUILD_RESULTS.md for the checksum and final mGBA result.

No menus, new songs, sustain mechanics or other gameplay systems were added. Human audio/play-feel and hardware validation remain outstanding. Existing scoring/replay limitations and asset licensing gaps are documented; no ROM binary or existing art/music is newly published in this PR.
