## Problem and result

Mission004 could inspect Clone Hero packages but could not feed them into GBA
gameplay. This adds one explicit Easy lead-guitar path: normalized timestamps
become CPU-cycle Note records for the existing judgment engine, displayed on a
three-lane perspective floor with Left/A/B. A minimal selector chooses Original
Demo or Imported Easy Test; Start+Select returns and resets state cleanly.
Imported mode is silent. The original four-lane controls, chart, music, judgment
windows and legacy timing formulas remain unchanged.

Computer-side validation preserves notes/native lengths, distinguishes short MIDI
release lengths using documented ceil(PPQ/3), rejects incompatible lanes/SysEx,
checks bounds/duplicates/ordering/visible density and reports retained unsupported
semantics. Sustains are data only, with no tails or held-note gameplay. The default
build uses a labeled original25-note fixture. A local prepared header is explicit;
switching builds regenerates it so stale private selection cannot leak into default.

The owner supplied the actual Cream/WaveGroup ZIP. It was privately inspected,
adapted and tested:395Easy notes,317short releases/78genuine sustains,329tempo
points. No third-party chart/audio, normalized private notes or private chart-ROM
is committed/published. Public downloads contain synthetic imported content only.

## Validation

-75Python tests passed (32chart,34MIDI/package,9adaptation), no skips in this
 environment; old and new C++ ASan/UBSan/leak/runtime tests passed.
-Independent absolute/boundary/first/final/reference timing, hour-long/overflow
 bounds, frame rounding, mapping, repeated state reset and skipped-frame misses.
-Clean native/default and pinned Docker outputs agree:278780bytes, SHA256
 `ddd51770e8f8c037df3cc66bf128f49f777e49638c3d4f1de7a0d0dbd8252883`.
-All699 original linked chart records independently match the legacy conversion.
-mGBA0.10.1 original perfect/miss/mixed:36000frames each, all passed.
-Synthetic Easy perfect/miss:1800frames each,25notes; private real Easy
 perfect/miss:18000frames each,395notes. Every note counted once, imported
 output silent. Each scenario also exercises three original/imported return cycles.
-Visual inspection of selector/three-lane screenshots; no human hand-play,
 listening, hardware/latency calibration or actual imported audio sync claim.
-Measured hit error max16.700745ms synthetic/16.694248ms real, within one GBA frame.

## Boundaries and review

No OPUS decoding, compression, mixing/reactive audio, scoring, sustain mechanics,
imported Medium/Hard or multi-song menu. Future audio must define sample-clock,
latency and recording alignment. See GBA_CHART_ADAPTATION.md for exact rules,
Windows11 preparation/build steps and limits; MISSION_005_RESULTS.md for evidence.

Review against mission-004-universal-import; all previous mission branches remain
unmerged into main. No automatic merge. The public download branch is separate
and must not be merged. Complete tracked-source bundle excludes ignored/private
inputs/output. Current permission limitations for original music/art are retained.
