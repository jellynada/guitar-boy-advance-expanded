Imported PCM callbacks can delay or lose the old HBlank renderer, displacing highway scanlines. Double-buffered affine/fog tables now use bounded HBlank DMA, preserving projection, assets, scoring and playback rules.

Outcome B: full real-song graphics now show zero displaced pixels across16086 eligible frames, with zero underruns. Exact FIFO bytes match the independent model. Two additional ordinary mGBA backing comparisons still fail; diagnostic emulator event correction explains them but does not count as acceptance. Stable promotion and owner acceptance remain blocked.

Validation:108 Python tests,8 sanitized C++ programs,17 synthetic scenarios,10 full real scenarios,5 input cases,3 long Original cases, fixed/silent compatibility, controlled timing matrix, deliberate negative failures and pinned clean Docker rebuilds. See docs/MISSION_011_AUDIO_GRAPHICS.md for measurements and limitations. Real song assets stay private. No merge, consolidation or stable tag requested.
