MISSION012 SYNTHETIC REVIEW BUILD
Extract All. Install mGBA from https://mgba.io/downloads.html.
File > Load ROM > Guitar-Boy-Advance-M012-Synthetic.gba
This public test song is synthetic. No Cream recording/chart is included.
To build privately: open guitar-boy-advance-expanded/docs/WINDOWS_PRIVATE_BUILD.md.
Place your own ZIP in private/Cream.zip and double-click Build-Cream-ROM.bat.
Review candidate, not a stable release. Read docs/KNOWN_ISSUES.md.
