GUITAR BOY ADVANCE EXPANDED - v0.1.0-alpha-RC1

Open Guitar-Boy-Advance-Expanded-v0.1.0-alpha-RC1.gba in mGBA, or copy it to a compatible GBA flash cartridge.
No compilation is needed.

Choose Copper Circuit, then Easy/Medium/Hard.
Easy: LEFT / B / A
Medium: LEFT / RIGHT / B / A
Hard: LEFT / UP-or-DOWN / RIGHT / B / A
Every note needs a fresh press. Keep sustains held for bonuses.
Misses mute guitar; a valid hit brings it back.
START: pause/resume. SELECT while paused: return.
Results: A/START replay; B/SELECT song selection.

Original 75-second composition, plus a 2-second count-in.
Source: 113fc49fbcec851631ee4a932320de7fa803e551
ROM SHA256: 243e4160c68c671a7b9e1d4dc0e2f4bb439294eccf62a1accf04b0aae5df6af6

Real-GBA owner acceptance pending. Public-demo strict emulator output
comparisons currently fail the unchanged 1ms limit: release gate blocked.
Historical full-length Cream emulator
output findings remain unresolved; this ROM contains no Cream recording.
Input diagnostics use the historical Easy test; Hard alias is described above.
Read LICENSES/OWNER_PERMISSION.txt and included third-party notices.
